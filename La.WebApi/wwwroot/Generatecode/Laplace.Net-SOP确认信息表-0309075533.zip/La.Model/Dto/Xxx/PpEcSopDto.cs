﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using La.Model.Dto;
using La.Model.Models;

namespace La.Model.Dto
{
    /// <summary>
    /// SOP确认信息表查询对象
    /// </summary>
    public class PpEcSopQueryDto : PagerInfo 
    {
    }

    /// <summary>
    /// SOP确认信息表输入输出对象
    /// </summary>
    public class PpEcSopDto
    {
        /// <summary>
        /// 描述 :ID 
        /// </summary>
        [Required(ErrorMessage = "ID不能为空")]

        public int EsId { get; set; }


        public DateTime? EsIssueDate { get; set; }


        public string EsEcNo { get; set; }

        /// <summary>
        /// 描述 :输入日期 
        /// </summary>
        [Required(ErrorMessage = "输入日期不能为空")]

        public DateTime? EsEntryDate { get; set; }


        public string EsAssigned { get; set; }


        public string EsModel { get; set; }


        public string EsPeaAssigned { get; set; }

        /// <summary>
        /// 描述 :组立变更否 
        /// </summary>
        [Required(ErrorMessage = "组立变更否不能为空")]

        public bool IsPeaModifysop { get; set; }


        public string EsPeaDate { get; set; }


        public string EsPeaNote { get; set; }


        public string EsPeaModifier { get; set; }


        public DateTime? EsPeaModifyTime { get; set; }


        public string EsPepAssigned { get; set; }

        /// <summary>
        /// 描述 :PCBA变更否 
        /// </summary>
        [Required(ErrorMessage = "PCBA变更否不能为空")]

        public bool IsPepModifysop { get; set; }


        public string EsPepDate { get; set; }


        public string EsPepNote { get; set; }


        public string EsPepModifier { get; set; }


        public DateTime? EsPepModifyTime { get; set; }


        public string UDF01 { get; set; }


        public string UDF02 { get; set; }


        public string UDF03 { get; set; }


        public string UDF04 { get; set; }


        public string UDF05 { get; set; }


        public string UDF06 { get; set; }

        /// <summary>
        /// 描述 : 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]

        public decimal UDF51 { get; set; }

        /// <summary>
        /// 描述 : 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]

        public decimal UDF52 { get; set; }

        /// <summary>
        /// 描述 : 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]

        public decimal UDF53 { get; set; }

        /// <summary>
        /// 描述 : 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]

        public decimal UDF54 { get; set; }

        /// <summary>
        /// 描述 : 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]

        public decimal UDF55 { get; set; }

        /// <summary>
        /// 描述 : 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]

        public decimal UDF56 { get; set; }

        /// <summary>
        /// 描述 : 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]

        public bool IsDeleted { get; set; }


        public string ReMark { get; set; }


        public string CreateBy { get; set; }


        public DateTime? CreateTime { get; set; }


        public string UpdateBy { get; set; }


        public DateTime? UpdateTime { get; set; }



    }
}