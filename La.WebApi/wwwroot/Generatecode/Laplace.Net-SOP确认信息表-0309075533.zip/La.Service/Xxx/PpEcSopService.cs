using System;
using SqlSugar;
using La.Infra.Attribute;
using La.Model;
using La.Model.Dto;
using La.Model.Models;
using La.Model.System;
using La.Repository;
using La.Service.Xxx.IXxxService;
using System.Linq;

namespace La.Service.Xxx
{
    /// <summary>
    /// SOP确认信息表Service业务层处理
    ///
    /// @author Laplace.Net:Davis.Cheng
    /// @date 2023-03-09
    /// </summary>
    [AppService(ServiceType = typeof(IPpEcSopService), ServiceLifetime = LifeTime.Transient)]
    public class PpEcSopService : BaseService<PpEcSop>, IPpEcSopService
    {
        #region 业务逻辑代码

        /// <summary>
        /// 查询SOP确认信息表列表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        public PagedInfo<PpEcSopDto> GetList(PpEcSopQueryDto parm)
        {
            //开始拼装查询条件
            var predicate = Expressionable.Create<PpEcSop>();

            //搜索条件查询语法参考Sqlsugar
            var response = Queryable()
                .Where(predicate.ToExpression())
                .ToPage<PpEcSop, PpEcSopDto>(parm);

            return response;
        }


        /// <summary>
        /// 校验输入项目是否唯一
        /// </summary>
        /// <param name="entryString"></param>
        /// <returns></returns>
        public string CheckEntryStringUnique(string entryString)
        {
            int count = Count(it => it.EsId.ToString() == entryString);
            if (count > 0)
            {
                return UserConstants.NOT_UNIQUE;
            }
            return UserConstants.UNIQUE;
        }

        /// <summary>
        /// 添加SOP确认信息表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        public int AddPpEcSop(PpEcSop parm)
        {
            var response = Insert(parm, it => new
            {
                it.EsIssueDate,
                it.EsEcNo,
                it.EsEntryDate,
                it.EsAssigned,
                it.EsModel,
                it.EsPeaAssigned,
                it.IsPeaModifysop,
                it.EsPeaDate,
                it.EsPeaNote,
                it.EsPeaModifier,
                it.EsPeaModifyTime,
                it.EsPepAssigned,
                it.IsPepModifysop,
                it.EsPepDate,
                it.EsPepNote,
                it.EsPepModifier,
                it.EsPepModifyTime,
                it.UDF01,
                it.UDF02,
                it.UDF03,
                it.UDF04,
                it.UDF05,
                it.UDF06,
                it.UDF51,
                it.UDF52,
                it.UDF53,
                it.UDF54,
                it.UDF55,
                it.UDF56,
                it.IsDeleted,
                it.ReMark,
                it.CreateBy,
                it.CreateTime,
                it.UpdateBy,
                it.UpdateTime,
            });
            return response;
        }

        /// <summary>
        /// 修改SOP确认信息表
        /// </summary>
        /// <param name="parm"></param>
        /// <returns></returns>
        public int UpdatePpEcSop(PpEcSop parm)
        {
            var response = Update(w => w.EsId == parm.EsId, it => new PpEcSop()
            {
                EsIssueDate = parm.EsIssueDate,
                EsEcNo = parm.EsEcNo,
                EsEntryDate = parm.EsEntryDate,
                EsAssigned = parm.EsAssigned,
                EsModel = parm.EsModel,
                EsPeaAssigned = parm.EsPeaAssigned,
                IsPeaModifysop = parm.IsPeaModifysop,
                EsPeaDate = parm.EsPeaDate,
                EsPeaNote = parm.EsPeaNote,
                EsPeaModifier = parm.EsPeaModifier,
                EsPeaModifyTime = parm.EsPeaModifyTime,
                EsPepAssigned = parm.EsPepAssigned,
                IsPepModifysop = parm.IsPepModifysop,
                EsPepDate = parm.EsPepDate,
                EsPepNote = parm.EsPepNote,
                EsPepModifier = parm.EsPepModifier,
                EsPepModifyTime = parm.EsPepModifyTime,
                UDF01 = parm.UDF01,
                UDF02 = parm.UDF02,
                UDF03 = parm.UDF03,
                UDF04 = parm.UDF04,
                UDF05 = parm.UDF05,
                UDF06 = parm.UDF06,
                UDF51 = parm.UDF51,
                UDF52 = parm.UDF52,
                UDF53 = parm.UDF53,
                UDF54 = parm.UDF54,
                UDF55 = parm.UDF55,
                UDF56 = parm.UDF56,
                ReMark = parm.ReMark,
            });
            return response;
        }

        /// <summary>
        /// 清空SOP确认信息表
        /// </summary>
        /// <returns></returns>
        public void TruncatePpEcSop()
        {
            Truncate();
        }
        #endregion
    }
}