import request from '@/utils/request'

/**
* 工厂物料评估分页查询
* @param {查询条件} data
*/
export function listMmMbew(query) {
  return request({
    url: 'xxx/MmMbew/list',
    method: 'get',
    params: query,
  })
}


/**
* 新增工厂物料评估
* @param data
*/
export function addMmMbew(data) {
  return request({
    url: 'xxx/MmMbew',
    method: 'post',
    data: data,
  })
}

/**
* 修改工厂物料评估
* @param data
*/
export function updateMmMbew(data) {
  return request({
    url: 'xxx/MmMbew',
    method: 'PUT',
    data: data,
  })
}

/**
* 获取工厂物料评估详情
* @param {Id}
*/
export function getMmMbew(id) {
  return request({
    url: 'xxx/MmMbew/' + id,
    method: 'get'
  })
}

/**
* 删除工厂物料评估
* @param {主键} pid
*/
export function delMmMbew(pid) {
  return request({
    url: 'xxx/MmMbew/' + pid,
    method: 'delete'
  })
}

// 清空工厂物料评估
export function clearMmMbew() {
  return request({
    url: 'xxx/MmMbew/clean',
    method: 'delete'
  })
}

// 导出工厂物料评估
export async function exportMmMbew(query) {
  await downFile('xxx/MmMbew/export', { ...query })
}

