﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using La.Model.Dto;
using La.Model.Models;

namespace La.Model.Dto
{
    /// <summary>
    /// 工厂物料评估查询对象
    /// </summary>
    public class MmMbewQueryDto : PagerInfo 
    {
    }

    /// <summary>
    /// 工厂物料评估输入输出对象
    /// </summary>
    public class MmMbewDto
    {
        /// <summary>
        /// 描述 :ID主键 
        /// </summary>
        [Required(ErrorMessage = "ID主键不能为空")]
        public int MbewID { get; set; }

        public string MbewABCIW { get; set; }

        public string MbewABWKZ { get; set; }

        public string MbewBKLAS { get; set; }

        /// <summary>
        /// 描述 :评估范围 
        /// </summary>
        [Required(ErrorMessage = "评估范围不能为空")]
        public string MbewBWKEY { get; set; }

        /// <summary>
        /// 描述 :价格单位 
        /// </summary>
        [Required(ErrorMessage = "价格单位不能为空")]
        public decimal MbewBWPEI { get; set; }

        /// <summary>
        /// 描述 :商业价格 2 
        /// </summary>
        [Required(ErrorMessage = "商业价格 2不能为空")]
        public decimal MbewBWPH1 { get; set; }

        /// <summary>
        /// 描述 :商业价格 1 
        /// </summary>
        [Required(ErrorMessage = "商业价格 1不能为空")]
        public decimal MbewBWPRH { get; set; }

        /// <summary>
        /// 描述 :税价1 
        /// </summary>
        [Required(ErrorMessage = "税价1不能为空")]
        public decimal MbewBWPRS { get; set; }

        /// <summary>
        /// 描述 :税价2 
        /// </summary>
        [Required(ErrorMessage = "税价2不能为空")]
        public decimal MbewBWPS1 { get; set; }

        /// <summary>
        /// 描述 :评价毛利 
        /// </summary>
        [Required(ErrorMessage = "评价毛利不能为空")]
        public decimal MbewBWSPA { get; set; }

        /// <summary>
        /// 描述 :评估类型 
        /// </summary>
        [Required(ErrorMessage = "评估类型不能为空")]
        public string MbewBWTAR { get; set; }

        public string MbewBWTTY { get; set; }

        public string MbewBWVA1 { get; set; }

        public string MbewBWVA2 { get; set; }

        public string MbewBWVA3 { get; set; }

        public string MbewEKALR { get; set; }

        public string MbewEKLAS { get; set; }

        public string MbewFBWST { get; set; }

        /// <summary>
        /// 描述 :固定的未来计划价格 
        /// </summary>
        [Required(ErrorMessage = "固定的未来计划价格不能为空")]
        public decimal MbewFPLPX { get; set; }

        public string MbewHKMAT { get; set; }

        public string MbewHRKFT { get; set; }

        public string MbewKALKL { get; set; }

        public string MbewKALKV { get; set; }

        public string MbewKALKZ { get; set; }

        public string MbewKALN1 { get; set; }

        public string MbewKALNR { get; set; }

        public string MbewKALSC { get; set; }

        public string MbewKOSGR { get; set; }

        public string MbewKZIWL { get; set; }

        public DateTime? MbewLAEPR { get; set; }

        /// <summary>
        /// 描述 :总库存  
        /// </summary>
        [Required(ErrorMessage = "总库存 不能为空")]
        public decimal MbewLBKUM { get; set; }

        public string MbewLBWST { get; set; }

        public string MbewLFGJA { get; set; }

        public string MbewLFMON { get; set; }

        /// <summary>
        /// 描述 :当前计划价格 
        /// </summary>
        [Required(ErrorMessage = "当前计划价格不能为空")]
        public decimal MbewLPLPR { get; set; }

        /// <summary>
        /// 描述 :固定的当前计划价格 
        /// </summary>
        [Required(ErrorMessage = "固定的当前计划价格不能为空")]
        public decimal MbewLPLPX { get; set; }

        public string MbewLVORM { get; set; }

        /// <summary>
        /// 描述 :集团 
        /// </summary>
        [Required(ErrorMessage = "集团不能为空")]
        public string MbewMANDT { get; set; }

        /// <summary>
        /// 描述 :物料 
        /// </summary>
        [Required(ErrorMessage = "物料不能为空")]
        public string MbewMATNR { get; set; }

        public string MbewMBRUE { get; set; }

        public string MbewMLAST { get; set; }

        public string MbewMLMAA { get; set; }

        public string MbewMTORG { get; set; }

        public string MbewMTUSE { get; set; }

        public string MbewMYPOL { get; set; }

        public string MbewOIPPINV { get; set; }

        public string MbewOKLAS { get; set; }

        public string MbewOWNPR { get; set; }

        public string MbewPDATL { get; set; }

        public string MbewPDATV { get; set; }

        public string MbewPDATZ { get; set; }

        /// <summary>
        /// 描述 :价格单位 
        /// </summary>
        [Required(ErrorMessage = "价格单位不能为空")]
        public decimal MbewPEINH { get; set; }

        public string MbewPPERL { get; set; }

        public string MbewPPERV { get; set; }

        public string MbewPPERZ { get; set; }

        public string MbewPPRDL { get; set; }

        public string MbewPPRDV { get; set; }

        public string MbewPPRDZ { get; set; }

        public string MbewPSTAT { get; set; }

        public string MbewQKLAS { get; set; }

        /// <summary>
        /// 描述 :总价值  
        /// </summary>
        [Required(ErrorMessage = "总价值 不能为空")]
        public decimal MbewSALK3 { get; set; }

        /// <summary>
        /// 描述 :价值/MA价格 
        /// </summary>
        [Required(ErrorMessage = "价值/MA价格不能为空")]
        public decimal MbewSALKV { get; set; }

        public string MbewSPERW { get; set; }

        /// <summary>
        /// 描述 :标准价格 
        /// </summary>
        [Required(ErrorMessage = "标准价格不能为空")]
        public decimal MbewSTPRS { get; set; }

        /// <summary>
        /// 描述 :上期价格 
        /// </summary>
        [Required(ErrorMessage = "上期价格不能为空")]
        public decimal MbewSTPRV { get; set; }

        /// <summary>
        /// 描述 :时戳 
        /// </summary>
        [Required(ErrorMessage = "时戳不能为空")]
        public decimal MbewTIMESTAMP { get; set; }

        public string MbewVBWST { get; set; }

        /// <summary>
        /// 描述 :移动价格 
        /// </summary>
        [Required(ErrorMessage = "移动价格不能为空")]
        public decimal MbewVERPR { get; set; }

        public string MbewVERS1 { get; set; }

        public string MbewVERS2 { get; set; }

        public string MbewVERS3 { get; set; }

        public string MbewVJBKL { get; set; }

        /// <summary>
        /// 描述 :商业价格 3 
        /// </summary>
        [Required(ErrorMessage = "商业价格 3不能为空")]
        public decimal MbewVJBWH { get; set; }

        /// <summary>
        /// 描述 :税价3 
        /// </summary>
        [Required(ErrorMessage = "税价3不能为空")]
        public decimal MbewVJBWS { get; set; }

        /// <summary>
        /// 描述 :前年总库存值  
        /// </summary>
        [Required(ErrorMessage = "前年总库存值 不能为空")]
        public decimal MbewVJKUM { get; set; }

        /// <summary>
        /// 描述 :上年价格单位 
        /// </summary>
        [Required(ErrorMessage = "上年价格单位不能为空")]
        public decimal MbewVJPEI { get; set; }

        /// <summary>
        /// 描述 :上年总值  
        /// </summary>
        [Required(ErrorMessage = "上年总值 不能为空")]
        public decimal MbewVJSAL { get; set; }

        /// <summary>
        /// 描述 :上年价值  
        /// </summary>
        [Required(ErrorMessage = "上年价值 不能为空")]
        public decimal MbewVJSAV { get; set; }

        /// <summary>
        /// 描述 :去年标准价格 
        /// </summary>
        [Required(ErrorMessage = "去年标准价格不能为空")]
        public decimal MbewVJSTP { get; set; }

        /// <summary>
        /// 描述 :去年移动平均价 
        /// </summary>
        [Required(ErrorMessage = "去年移动平均价不能为空")]
        public decimal MbewVJVER { get; set; }

        public string MbewVJVPR { get; set; }

        /// <summary>
        /// 描述 :总SP值  
        /// </summary>
        [Required(ErrorMessage = "总SP值 不能为空")]
        public decimal MbewVKSAL { get; set; }

        public string MbewVMBKL { get; set; }

        /// <summary>
        /// 描述 :前期总库存  
        /// </summary>
        [Required(ErrorMessage = "前期总库存 不能为空")]
        public decimal MbewVMKUM { get; set; }

        /// <summary>
        /// 描述 :上期间价格单位 
        /// </summary>
        [Required(ErrorMessage = "上期间价格单位不能为空")]
        public decimal MbewVMPEI { get; set; }

        /// <summary>
        /// 描述 :前期总值  
        /// </summary>
        [Required(ErrorMessage = "前期总值 不能为空")]
        public decimal MbewVMSAL { get; set; }

        /// <summary>
        /// 描述 :上期的价值  
        /// </summary>
        [Required(ErrorMessage = "上期的价值 不能为空")]
        public decimal MbewVMSAV { get; set; }

        /// <summary>
        /// 描述 :前期标准价格 
        /// </summary>
        [Required(ErrorMessage = "前期标准价格不能为空")]
        public decimal MbewVMSTP { get; set; }

        /// <summary>
        /// 描述 :前期移动平均价 
        /// </summary>
        [Required(ErrorMessage = "前期移动平均价不能为空")]
        public decimal MbewVMVER { get; set; }

        public string MbewVMVPR { get; set; }

        /// <summary>
        /// 描述 :上期标准价格 
        /// </summary>
        [Required(ErrorMessage = "上期标准价格不能为空")]
        public decimal MbewVPLPR { get; set; }

        /// <summary>
        /// 描述 :固定的上年计划价格 
        /// </summary>
        [Required(ErrorMessage = "固定的上年计划价格不能为空")]
        public decimal MbewVPLPX { get; set; }

        public string MbewVPRSV { get; set; }

        /// <summary>
        /// 描述 :前年的总库存  
        /// </summary>
        [Required(ErrorMessage = "前年的总库存 不能为空")]
        public decimal MbewVVJLB { get; set; }

        /// <summary>
        /// 描述 :计价在  
        /// </summary>
        [Required(ErrorMessage = "计价在 不能为空")]
        public decimal MbewVVJSL { get; set; }

        /// <summary>
        /// 描述 :前期的总库存值 
        /// </summary>
        [Required(ErrorMessage = "前期的总库存值不能为空")]
        public decimal MbewVVMLB { get; set; }

        /// <summary>
        /// 描述 :计价在  
        /// </summary>
        [Required(ErrorMessage = "计价在 不能为空")]
        public decimal MbewVVSAL { get; set; }

        public DateTime? MbewWLINL { get; set; }

        public string MbewXBEWM { get; set; }

        public string MbewXLIFO { get; set; }

        public DateTime? MbewZKDAT { get; set; }

        /// <summary>
        /// 描述 :未来价格 
        /// </summary>
        [Required(ErrorMessage = "未来价格不能为空")]
        public decimal MbewZKPRS { get; set; }

        public DateTime? MbewZPLD1 { get; set; }

        public DateTime? MbewZPLD2 { get; set; }

        public DateTime? MbewZPLD3 { get; set; }

        /// <summary>
        /// 描述 :计划价格 1 
        /// </summary>
        [Required(ErrorMessage = "计划价格 1不能为空")]
        public decimal MbewZPLP1 { get; set; }

        /// <summary>
        /// 描述 :计划价格 2 
        /// </summary>
        [Required(ErrorMessage = "计划价格 2不能为空")]
        public decimal MbewZPLP2 { get; set; }

        /// <summary>
        /// 描述 :计划价格 3 
        /// </summary>
        [Required(ErrorMessage = "计划价格 3不能为空")]
        public decimal MbewZPLP3 { get; set; }

        /// <summary>
        /// 描述 :未来计划价格 
        /// </summary>
        [Required(ErrorMessage = "未来计划价格不能为空")]
        public decimal MbewZPLPR { get; set; }

        public string UDF01 { get; set; }

        public string UDF02 { get; set; }

        public string UDF03 { get; set; }

        public string UDF04 { get; set; }

        public string UDF05 { get; set; }

        public string UDF06 { get; set; }

        public decimal UDF51 { get; set; }

        public decimal UDF52 { get; set; }

        public decimal UDF53 { get; set; }

        public decimal UDF54 { get; set; }

        public decimal UDF55 { get; set; }

        public decimal UDF56 { get; set; }

        public bool IsDeleted { get; set; }

        public string Remark { get; set; }

        public string CreateBy { get; set; }

        public DateTime? CreateTime { get; set; }

        public string UpdateBy { get; set; }

        public DateTime? UpdateTime { get; set; }



    }
}