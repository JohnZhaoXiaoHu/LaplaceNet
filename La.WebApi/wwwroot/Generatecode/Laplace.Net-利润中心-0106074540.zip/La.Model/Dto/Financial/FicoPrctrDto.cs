﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using La.Model.Dto;
using La.Model.Models;
using MiniExcelLibs.Attributes;

namespace La.Model.Dto
{
    /// <summary>
    /// 利润中心查询对象
    /// </summary>
    public class FicoPrctrQueryDto : PagerInfo 
    {
    }

    /// <summary>
    /// 利润中心输入输出对象
    /// </summary>
    public class FicoPrctrDto
    {
        [Required(ErrorMessage = "Id主键不能为空")]
        [ExcelColumn(Name = "Id主键")]
        public long FpId { get; set; }

        [Required(ErrorMessage = "工厂不能为空")]
        [ExcelColumn(Name = "工厂")]
        public string FpPlnt { get; set; }

        [Required(ErrorMessage = "代码不能为空")]
        [ExcelColumn(Name = "代码")]
        public string FpCode { get; set; }

        [Required(ErrorMessage = "名称不能为空")]
        [ExcelColumn(Name = "名称")]
        public string FpName { get; set; }

        [Required(ErrorMessage = "类别不能为空")]
        [ExcelColumn(Name = "类别")]
        public string FpType { get; set; }

        [Required(ErrorMessage = "有效从不能为空")]
        [ExcelColumn(Name = "有效从", Format = "yyyy-MM-dd HH:mm:ss")]
        public DateTime? FpActDate { get; set; }

        [Required(ErrorMessage = "有效到不能为空")]
        [ExcelColumn(Name = "有效到", Format = "yyyy-MM-dd HH:mm:ss")]
        public DateTime? FpExpDate { get; set; }

        [Required(ErrorMessage = "不能为空")]
        [ExcelColumn(Name = "IsDeleted")]
        public bool IsDeleted { get; set; }

        [ExcelColumn(Name = "Remark")]
        public string Remark { get; set; }

        [ExcelColumn(Name = "CreateBy")]
        public string CreateBy { get; set; }

        [ExcelColumn(Name = "CreateTime", Format = "yyyy-MM-dd HH:mm:ss")]
        public DateTime? CreateTime { get; set; }

        [ExcelColumn(Name = "UpdateBy")]
        public string UpdateBy { get; set; }

        [ExcelColumn(Name = "UpdateTime", Format = "yyyy-MM-dd HH:mm:ss")]
        public DateTime? UpdateTime { get; set; }



    }
}